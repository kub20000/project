//package com.bproject.user.controller;
//
//import com.bproject.user.entity.User;
//import com.bproject.user.service.UserService;
//import jakarta.servlet.http.HttpSession;
//import lombok.RequiredArgsConstructor;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//@RequiredArgsConstructor
//@Controller
//@RequestMapping("/login") // 화면 라우팅은 /user 아래로
//public class UserMvcController {
//
//    private final UserService userService;
//
//    @GetMapping("/")
//    public String root() {
//        return "redirect:/";
//    }
//
//    // 홈 화면
//    @GetMapping("/in")
//    public String index() {
//        return "home";  // templates/user/index.html
//    }
//
//    // 로그인 화면
//    @GetMapping("/login")
//    public String loginPage() {
//        return "login/login"; // templates/login/login.html
//    }
//
//    // 회원가입 화면
//    @GetMapping("/join")
//    public String joinPage() {
//        return "login/joinUser"; // templates/login/joinUser.html
//    }
//
//    // 마이페이지 (로그인 필요)
//    @GetMapping("/mypage")
//    public String mypage(HttpSession session, Model model) {
//        User loginUser = (User) session.getAttribute("loginUser");
//        if (loginUser == null) return "redirect:/user/login";
//        model.addAttribute("user", loginUser);
//        return "user/mypage"; // templates/user/mypage.html
//    }
//
//    // 내 정보 보기/수정 화면
//    @GetMapping("/myinfo")
//    public String myinfo(HttpSession session, Model model) {
//        User loginUser = (User) session.getAttribute("loginUser");
//        if (loginUser == null) return "redirect:/user/login";
//        model.addAttribute("user", loginUser);
//        return "user/myinfo"; // templates/user/myinfo.html
//    }
//
//}
