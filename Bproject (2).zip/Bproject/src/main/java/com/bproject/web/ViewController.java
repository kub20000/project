// src/main/java/com/bproject/web/ViewController.java
package com.bproject.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ViewController {


    // 홈 화면
    @GetMapping("/index")
    public String index() {
        return "home";  // templates/user/index.html
    }
    @GetMapping("/mypage")
    public String mypage() {
        return"mypage/myBoard";
    }
    @GetMapping("/mainhome")
    public String mainhome() {
        return "mainhome";
    }
    @GetMapping("/")
    public String home() {
        return "home"; // templates/home.html
    }

    @GetMapping("/course/main")
    public String course() {return "/course/courses";}

    @GetMapping("/post/main")
    public String postMain(){
        return "redirect:/post/list";
    }

    @GetMapping("/myFridge")
    public String myFridge() {
        return "myFridge/myFridge"; // templates/myFridge/myFridge.html
    }

    @GetMapping("/teacher/uploadCourse")
    public String uploadCourse() {return "/teacher/uploadCourse";}

    @GetMapping("/logout")
    public String logout() {
        return "home";
    }


    @GetMapping("/myinfo")
    public String myinfo() {
        return "mypage/myinfo";
    }
    @GetMapping("/deleteinfo")
    public String deleteinfo() {
        return "mypage/deleteinfo";
    }

    @GetMapping("/myStudy")
    public String myStudy() {
        return "mypage/myStudy";
    }
    @GetMapping("/myRecipe")
    public String myRecipe() {
        return "mypage/myRecipe";
    }
    @GetMapping("/myBaord")
    public String myBaord() {
        return "mypage/myBaord";
    }
    @GetMapping("/courses")
    public String courses() {
        return "Course/courses";
    }
    // 로그인 화면
    @GetMapping("/login")
    public String loginPage() {
        return "login/login"; // templates/login/login.html
    }

    // 회원가입 화면
    @GetMapping("/join")
    public String joinPage() {
        return "login/joinUser"; // templates/login/joinUser.html
    }


}
