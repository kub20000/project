package com.bproject.myfridge;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/mypage")
public class MyFridgeViewController {

    private final MyFridgeDao dao;
    public MyFridgeViewController(MyFridgeDao dao) { this.dao = dao; }

    @GetMapping("/myRecipe")
    public String myRecipes(Model model, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";
        model.addAttribute("recipes", dao.findByUser(userId));
        return "mypage/myRecipe";
    }
}
