package com.bproject.myfridge;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.List;

@Repository
public class MyFridgeDao {
    private final JdbcTemplate jdbc;
    public MyFridgeDao(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    /** 저장 버튼용: 제목/재료/본문 저장 + 생성된 PK 반환 */
    public Long insertRecipe(Long userId, String title, String recipe, String ingredientsCsv) {
        final String sql = "INSERT INTO myfridge (user_id, title, ingredients, recipe, created_at) " +
                "VALUES (?, ?, ?, ?, NOW())";
        KeyHolder kh = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            if (userId == null) ps.setNull(1, Types.BIGINT); else ps.setLong(1, userId);
            ps.setString(2, title);
            ps.setString(3, ingredientsCsv == null ? "" : ingredientsCsv);
            ps.setString(4, recipe);
            return ps;
        }, kh);
        Number key = kh.getKey();
        return key == null ? null : key.longValue();
    }

    /** 나의 레시피 목록 조회 (템플릿에서 r.id/r.title/r.recipe 사용) */
    public List<RecipeRow> findByUser(Long userId) {
        String sql = "SELECT id, title, recipe FROM myfridge WHERE user_id = ? ORDER BY id DESC";
        return jdbc.query(sql, (rs, i) ->
                        new RecipeRow(rs.getLong("id"), rs.getString("title"), rs.getString("recipe")),
                userId
        );
    }

    public record RecipeRow(Long id, String title, String recipe) {}
}
