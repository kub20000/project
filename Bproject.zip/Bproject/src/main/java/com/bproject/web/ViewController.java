// src/main/java/com/bproject/web/ViewController.java
package com.bproject.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ViewController {


    // 로그인전 홈 화면
    @GetMapping("/")
    public String home() {
        return "home";  // templates/user/index.html
    }

    @GetMapping("/home")
    public String returnhome(){
        return "home";
    }

    @GetMapping("/mainhome")
    public String mainhome() {
        return "mainhome"; // templates/home.html
    }


    @GetMapping("course/main")
    public String course() {return "/course/courses";}

    @GetMapping("post/main")
    public String postMain(){
        return "redirect:/post/list";
    }


    @GetMapping("/teacher/uploadCourse")
    public String uploadCourse() {return "/teacher/uploadCourse";}

    @GetMapping("/teacher/port")
    public String port() {return "/teacher/port";}

    @GetMapping("/teacher/myCourse")
    public String myCourse() {return "/teacher/myCourse";}

    @GetMapping("/myStudy")
    public String myStudy() {
        return "mypage/myStudy";
    }
    @GetMapping("/myRecipe")
    public String myRecipe() {
        return "mypage/myRecipe";
    }
    @GetMapping("/myBoard")
    public String myBaord() {
        return "mypage/myBoard";
    }


}
