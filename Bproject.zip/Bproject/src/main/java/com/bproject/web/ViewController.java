// src/main/java/com/bproject/web/ViewController.java
package com.bproject.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ViewController {


    // 홈 화면
    @GetMapping("/index")
    public String index() {
        return "home";  // templates/user/index.html
    }
    @GetMapping("/mypage")
    public String mypage() {
        return"mypage/myBoard";
    }

    @GetMapping("/")
    public String home() {
        return "home"; // templates/home.html
    }

    @GetMapping("/course/main")
    public String course() {return "/course/courses";}

    @GetMapping("/post/main")
    public String postMain(){
        return "redirect:/post/list";
    }
    @GetMapping("/myFridge")
    public String myFridge() {
        return "myFridge/myFridge"; // templates/myFridge/myFridge.html
    }

    @GetMapping("/teacher/uploadCourse")
    public String uploadCourse() {return "/teacher/uploadCourse";}

    @GetMapping("/login")
    public String login() { return "/login/login"; } // templates/login.html

    @GetMapping("/join")
    public String joinUser() {
        return "login/joinUser";  // → templates/login/joinUser.html
    }

    @GetMapping("/logout")
    public String logout() {
        return "home";
    }
}
