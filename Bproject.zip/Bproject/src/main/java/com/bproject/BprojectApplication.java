package com.bproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(BprojectApplication.class, args);
    }

}
