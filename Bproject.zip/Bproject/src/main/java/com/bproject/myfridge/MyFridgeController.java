// src/main/java/com/bproject/myfridge/MyFridgeController.java
package com.bproject.myfridge;

import com.bproject.ai.AiService;
import com.bproject.myfridge.dto.RecipeRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/fridge")
@Slf4j
public class MyFridgeController {

    private final AiService aiService;
    private final MyFridgeDao dao;

    public MyFridgeController(AiService aiService, MyFridgeDao dao) {
        this.aiService = aiService;
        this.dao = dao;
    }

    @PostMapping(value = "/getRecipe", consumes = "application/json", produces = "application/json")
    public ResponseEntity<?> getRecipe(@RequestBody RecipeRequest req) {
        try {
            if (req == null || req.ingredients() == null || req.ingredients().isEmpty()) {
                return ResponseEntity.badRequest().body(
                        java.util.Map.of("error", "ingredients가 비어 있습니다.")
                );
            }

            String recipe = aiService.generateRecipe(req.ingredients());

            // DB 저장 (테이블: myfridge, 컬럼: ingredients, recipe)
            dao.insert(String.join(", ", req.ingredients()), recipe);

            return ResponseEntity.ok(java.util.Map.of(
                    "ingredients", req.ingredients(),
                    "recipe", recipe
            ));
        } catch (Exception e) {
            log.error("getRecipe failed", e);
            String msg = (e.getMessage() != null) ? e.getMessage() : e.getClass().getSimpleName();
            return ResponseEntity.internalServerError().body(java.util.Map.of("error", msg));
        }
    }

    @PostMapping(value = "/save", consumes = "application/json", produces = "application/json")
    public ResponseEntity<?> saveRecipe(@RequestBody RecipeRequest req) {
        try {
            if (req == null || req.ingredients() == null || req.ingredients().isEmpty()) {
                return ResponseEntity.badRequest().body(
                        java.util.Map.of("error", "ingredients가 비어 있습니다.")
                );
            }

            String recipe = aiService.generateRecipe(req.ingredients());
            dao.insert(String.join(", ", req.ingredients()), recipe);

            return ResponseEntity.ok(java.util.Map.of(
                    "ok", true,
                    "recipe", recipe
            ));
        } catch (Exception e) {
            log.error("saveRecipe failed", e);
            return ResponseEntity.internalServerError().body(
                    java.util.Map.of("error", e.getMessage())
            );
        }
    }

}
