// src/main/java/com/bproject/myfridge/MyFridgeDao.java
package com.bproject.myfridge;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.List;

@Repository
public class MyFridgeDao {
    private final JdbcTemplate jdbc;
    public MyFridgeDao(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public Long insertRecipe(Long userId, String title, String recipe, String ingredientsCsv) {
        final String sql = "INSERT INTO myfridge (user_id, title, ingredients, recipe, created_at) " +
                "VALUES (?, ?, ?, ?, NOW())";
        KeyHolder kh = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            if (userId == null) ps.setNull(1, Types.BIGINT); else ps.setLong(1, userId);
            ps.setString(2, title);
            ps.setString(3, ingredientsCsv == null ? "" : ingredientsCsv);
            ps.setString(4, recipe);
            return ps;
        }, kh);
        Number key = kh.getKey();
        return key == null ? null : key.longValue();
    }

    // ✅ POJO로 매핑
    public List<MyFridgeRecipe> findByUser(Long userId) {
        String sql = "SELECT id, title, ingredients, recipe FROM myfridge WHERE user_id = ? ORDER BY id DESC";
        return jdbc.query(sql, new BeanPropertyRowMapper<>(MyFridgeRecipe.class), userId);
    }
}
