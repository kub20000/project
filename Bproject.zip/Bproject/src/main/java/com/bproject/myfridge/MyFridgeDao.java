// src/main/java/com/bproject/myfridge/MyFridgeDao.java
package com.bproject.myfridge;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class MyFridgeDao {
    private final JdbcTemplate jdbc;
    private static final String TABLE = "myfridge"; // ← 테이블 이름

    public MyFridgeDao(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void insert(String ingredients, String recipe) {
        String sql = "INSERT INTO " + TABLE + " (ingredients, recipe) VALUES (?, ?)";
        jdbc.update(sql, ingredients, recipe);
    }
}
