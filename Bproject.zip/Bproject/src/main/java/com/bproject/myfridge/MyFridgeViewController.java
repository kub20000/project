// src/main/java/com/bproject/myfridge/MyFridgeViewController.java
package com.bproject.myfridge;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class MyFridgeViewController {

    private final MyFridgeDao myFridgeDao;
    public MyFridgeViewController(MyFridgeDao myFridgeDao) {
        this.myFridgeDao = myFridgeDao;
    }

    @GetMapping("/mypage/myRecipe")
    public String myRecipe(HttpSession session, Model model) {
        Object uid = session.getAttribute("userId");
        Long userId = (uid instanceof Number) ? ((Number) uid).longValue() : null;
        if (userId == null) return "redirect:/login";

        List<MyFridgeRecipe> recipes = myFridgeDao.findByUser(userId);

        // 디버그 로그
        System.out.println("[/mypage/myRecipe] userId=" + userId + " | count=" + recipes.size());
        if (!recipes.isEmpty()) {
            System.out.println(" first.title=" + recipes.get(0).getTitle());
        }

        // ★ 템플릿은 ${recipes}로 th:each를 돕니다
        model.addAttribute("recipes", recipes);

        // ★ 템플릿 경로가 templates/mypage/myRecipe.html 이므로 이렇게 반환
        return "mypage/myRecipe";
    }
}
