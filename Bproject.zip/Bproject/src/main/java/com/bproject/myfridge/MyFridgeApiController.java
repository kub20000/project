package com.bproject.myfridge;

import com.bproject.ai.AiService;
import com.bproject.myfridge.dto.RecipeRequest;
import com.bproject.myfridge.dto.RecipeSaveDto;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/fridge")
@Slf4j
public class MyFridgeApiController {

    private final AiService aiService;
    private final MyFridgeDao dao;

    public MyFridgeApiController(AiService aiService, MyFridgeDao dao) {
        this.aiService = aiService;
        this.dao = dao;
    }

    @PostMapping("/getRecipe") // consumes/produdes 일단 제거
    public ResponseEntity<?> getRecipe(@RequestBody RecipeRequest req) {
        if (req == null || req.ingredients() == null || req.ingredients().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "ingredients가 비어 있습니다."));
        }
        String recipe = aiService.generateRecipe(req.ingredients());
        return ResponseEntity.ok(Map.of("ingredients", req.ingredients(), "recipe", recipe));
    }

    @PostMapping("/save")
    public ResponseEntity<?> save(@RequestBody RecipeSaveDto dto, HttpSession session) {

        Object uid = session.getAttribute("userId");
        Long userId = (uid instanceof Number) ? ((Number) uid).longValue() : null;

        if (userId == null) {
            return ResponseEntity.status(401)
                    .body(Map.of("ok", false, "error", "LOGIN_REQUIRED"));
        }

        String title   = (dto.title()   == null || dto.title().isBlank()) ? "제목 없음" : dto.title().trim();
        String content = (dto.content() == null) ? "" : dto.content().trim();
        String ingredientsCsv = (dto.ingredients() == null) ? "" : String.join(", ", dto.ingredients());

        Long id = dao.insertRecipe(userId, title, content, ingredientsCsv);
        return ResponseEntity.ok(Map.of("ok", true, "id", id));
    }
}
