package com.bproject.myfridge.dto;

import java.util.List;

public record RecipeSaveDto(String title, String content, List<String> ingredients) {}
