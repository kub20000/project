// src/main/java/com/bproject/myfridge/dto/RecipeRequest.java
package com.bproject.myfridge.dto;
import java.util.List;
public record RecipeRequest(List<String> ingredients) {}

