// src/main/java/com/bproject/myfridge/MyFridgeRecipe.java
package com.bproject.myfridge;

public class MyFridgeRecipe {
    private Long id;
    private String title;
    private String ingredients;
    private String recipe;


    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getIngredients() { return ingredients; }
    public void setIngredients(String ingredients) { this.ingredients = ingredients; }

    public String getRecipe() { return recipe; }
    public void setRecipe(String recipe) { this.recipe = recipe; }
}
