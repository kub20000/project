package com.bproject.myfridge;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/fridge")
public class FridgePingController {
    @GetMapping("/ping")
    public String ping() { return "pong"; }
}