package com.bproject.ai;

import com.openai.client.OpenAIClient;
import com.openai.client.okhttp.OpenAIOkHttpClient;
import com.openai.models.responses.Response;
import com.openai.models.responses.ResponseCreateParams;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.stream.Collectors;

import java.util.List;

@Service
public class AiService {
    private final OpenAIClient client;
    private final String model;

    // fromEnv()는 OPENAI_API_KEY 환경변수를 자동으로 읽음
    public AiService(@Value("${openai.model}") String model) {
        this.client = OpenAIOkHttpClient.fromEnv();
        this.model = model; // 예: gpt-4.1-mini
    }

    public String generateRecipe(List<String> ingredients) {
        String prompt =
                "다음 재료로 만들 수 있는 쉽고 건강한 비건 레시피를 한글로 알려줘.\n" +
                        "- 형식: [레시피명] 한 줄 + 단계별 조리법 4~6단계.\n" +
                        "- 추가 규칙: 동물성 재료는 절대 포함하지 말 것.\n" +
                        "재료: " + String.join(", ", ingredients);

        ResponseCreateParams params = ResponseCreateParams.builder()
                .model(model)          // "gpt-4.1-mini"
                .input(prompt)         // 문자열 input 가능
                .maxOutputTokens(600)
                .build();

        try {
            Response res = client.responses().create(params);

            String text = res.output().stream()
                    .flatMap(item -> item.message().stream())
                    .flatMap(msg -> msg.content().stream())
                    .map(content -> content.outputText().map(t -> t.text()).orElse(""))
                    .filter(s -> !s.isEmpty())
                    .collect(java.util.stream.Collectors.joining("\n"));

            return text.trim();

        } catch (Exception e) {
            // 여기서 원인 파악 쉬움: 401(키 문제), 404(모델명), 429(요청 과다) 등
            System.err.println("[OpenAI call failed] " + e.getClass().getSimpleName() + ": " + e.getMessage());
            throw e; // 컨트롤러에서 잡아서 클라이언트에 간단 메시지 반환
        }
    }
}
