package com.bproject.user.entity;

public enum Role {
    ADMIN,
    USER,
    INSTRUCTOR;

}