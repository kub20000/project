package com.bproject.user.controller;

import com.bproject.user.entity.User;
import com.bproject.user.service.UserService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api") // API는 전부 /api
public class UserApiController {

    private final UserService userService;

    // 아이디(로그인ID) 중복 확인
    // 프론트: GET /api/check-nickname?userId=...
    @GetMapping("/check-nickname")
    public ResponseEntity<?> checkNickname(@RequestParam String userId) {
        boolean exists = userService.getUserByLoginId(userId).isPresent();
        if (exists) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("success", false, "message", "이미 사용 중인 아이디입니다."));
        }
        return ResponseEntity.ok(Map.of("success", true, "message", "사용 가능한 아이디입니다."));
    }

    // 회원가입 (DTO 없이 Map으로 받기)
    // 프론트: POST /api/register  (JSON)
    @PostMapping(value = "/register", consumes = "application/json")
    public ResponseEntity<?> register(@RequestBody Map<String, String> body) {
        String name = body.getOrDefault("name", "").trim();
        String username = body.getOrDefault("userId", "").trim(); // 프론트 키에 맞춤
        String nickname = body.getOrDefault("nickName", "").trim();
        String password = body.getOrDefault("password", "").trim();
        String birth = body.get("birth");
        String phone = body.get("phone");
        String email = body.get("email");

        if (username.isEmpty() || nickname.isEmpty() || password.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("success", false, "message", "필수값 누락(아이디/닉네임/비밀번호)"));
        }

        Optional<User> exists = userService.getUserByLoginId(username);
        if (exists.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("success", false, "message", "이미 존재하는 아이디입니다."));
        }

        User u = new User();
        u.setName(name);
        u.setUsername(username);
        u.setNickname(nickname);
        u.setPassword(password);
        if (birth != null && !birth.isBlank()) {
            u.setBirthdate(LocalDate.parse(birth)); // yyyy-MM-dd
        }
        u.setPhone(phone);
        u.setEmail(email);

        userService.addUser(u);

        return ResponseEntity.ok(Map.of("success", true, "message", "회원가입이 완료되었습니다."));
    }

    // 로그인 (fetch용 JSON)
    // 프론트: POST /api/login  (JSON: {username, password})
    @PostMapping(value = "/login", consumes = "application/json")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body, HttpSession session) {
        String username = body.getOrDefault("username", "");
        String password = body.getOrDefault("password", "");

        Optional<User> userOpt = userService.getUserByLoginId(username);
        if (userOpt.isPresent() && userOpt.get().getPassword().equals(password)) {
            session.setAttribute("loginUser", userOpt.get());
            return ResponseEntity.ok(Map.of("success", true));
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("success", false, "message", "아이디 또는 비밀번호가 올바르지 않습니다."));
    }

    // 비밀번호 변경 (fetch용 JSON)
    // 프론트: POST /api/change-password (JSON: {nowPw, newPw})
    @PostMapping(value = "/change-password", consumes = "application/json")
    public ResponseEntity<?> changePassword(@RequestBody Map<String, String> body, HttpSession session) {
        User loginUser = (User) session.getAttribute("loginUser");
        if (loginUser == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("success", false, "message", "로그인이 필요합니다."));
        }
        String nowPw = body.getOrDefault("nowPw", "");
        String newPw = body.getOrDefault("newPw", "");

        if (!loginUser.getPassword().equals(nowPw)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("success", false, "message", "현재 비밀번호가 일치하지 않습니다."));
        }
        if (newPw == null || newPw.isBlank()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("success", false, "message", "새 비밀번호가 비어있습니다."));
        }

        userService.updatePassword(loginUser.getId(), newPw);
        loginUser.setPassword(newPw);
        session.setAttribute("loginUser", loginUser);

        return ResponseEntity.ok(Map.of("success", true, "message", "비밀번호가 변경되었습니다."));
    }

    // 로그아웃 (선택)
    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpSession session) {
        session.invalidate();
        return ResponseEntity.ok(Map.of("success", true));
    }
}
