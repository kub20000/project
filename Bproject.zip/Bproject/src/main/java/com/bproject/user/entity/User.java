package com.bproject.user.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.management.relation.Role;
import java.sql.Timestamp;import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private int id;
    private String name;
    private String username;
    private String password;
    private String nickname;
    private LocalDate birthdate;
    private Role role;
    private String email;
    private String phone;
    private Timestamp created_at;
}