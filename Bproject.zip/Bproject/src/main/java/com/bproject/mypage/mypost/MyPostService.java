package com.bproject.mypage.mypost;

public class MyPostService {
}
