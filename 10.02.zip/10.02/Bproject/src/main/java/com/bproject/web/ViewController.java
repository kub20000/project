// src/main/java/com/bproject/web/ViewController.java
package com.bproject.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ViewController {


//    // 로그인전 홈 화면
//    @GetMapping("/")
//    public String home() {
//        return "home";  // templates/user/index.html
//    }

    @GetMapping("/home")
    public String returnhome(){
        return "home";
    }

    @GetMapping("/mainhome")
    public String mainhome() {
        return "mainhome"; // templates/home.html
    }

    @GetMapping("/myFridge")
    public String myFridge() {
        return "myFridge/myFridge";
    }





    @GetMapping("courses")
    public String course() {return "/courses/courses";}

//    @GetMapping("post/main")
//    public String postMain(){
//        return "redirect:/post/list";
//    }


    @GetMapping("/myStudy")
    public String myStudy() {
        return "mypage/myStudy";
    }
    @GetMapping("/myRecipe")
    public String myRecipe() {
        return "mypage/myRecipe";
    }
    @GetMapping("/myBoard")
    public String myBaord() {
        return "mypage/myBoard";
    }


}
