package com.bproject;

import jakarta.annotation.PostConstruct;import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;import java.nio.file.Paths;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    // 설정 없으면 사용자 홈 아래 uploads 사용
    @Value("${file.upload-path:${user.home}/uploads}")
    private String uploadPath;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 정적 리소스로 노출 (예: http://localhost:8080/uploads/파일명)
        String location = Paths.get(uploadPath).toUri().toString(); // "file:/C:/Bproject/uploads/" 형태
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations(location);
    }

    @PostConstruct
    void logPath() {
        System.out.println("[WebConfig] file.upload-path = " + uploadPath);
    }
}
