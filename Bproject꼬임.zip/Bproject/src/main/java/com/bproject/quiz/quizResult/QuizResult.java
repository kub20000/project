package com.bproject.quiz.quizResult;

public class QuizResult {
    private long id;
    private long quiz_id;

}
