package com.bproject.quiz.quizResult;

public class QuizResultRepo {
}
